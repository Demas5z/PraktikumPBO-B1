public class MenuTidakTersediaException extends Exception {
    public MenuTidakTersediaException(String message) {
        super(message);
    }
}