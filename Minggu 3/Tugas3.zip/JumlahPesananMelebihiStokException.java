public class JumlahPesananMelebihiStokException extends Exception {
    public JumlahPesananMelebihiStokException(String message){
      super(message);
    }

  // TO DO 2: Buat konstructor dengan parameter message dan panggil konstruktor parent dengan keyword super
} 