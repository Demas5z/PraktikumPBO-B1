/**
 * File : BangunDatar.java
 * Deskripsi : Kelas abstrak untuk bangun datar
 */

 public abstract class BangunDatar {
    public abstract double hitungKeliling();
}