/*
    Nama        : Demas Haikal Azizi
    NIM         : 24060122140161
    Nama File   : bukuAkademik.java
    Deskripsi   : File Class dari bukuAkademik.java
*/

package bk.bukunonFiksi;

public class bukuAkademik extends bukuNonFiksi{
    public bukuAkademik(String judul, String penulis, String tahunPenerbit, String subjek, int jumlahHalaman, double harga){
        super(judul, penulis, tahunPenerbit, subjek, jumlahHalaman, harga);
    }
}