/*
    Nama        : Demas Haikal Azizi
    NIM         : 24060122140161
    Nama File   : bukuNovel.java
    Deskripsi   : File Class dari bukuNovel.java
*/

package bk.bukuFiksi;

public class bukuNovel extends bukuFiksi{
    public bukuNovel(String judul, String penulis, String tahunPenerbit, String genre, int jumlahHalaman, double harga) {
        super(judul, penulis, tahunPenerbit, genre, jumlahHalaman, harga);
    }
}